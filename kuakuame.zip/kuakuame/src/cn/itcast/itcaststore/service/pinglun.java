package cn.itcast.itcaststore.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.ArrayListHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
 
import cn.itcast.itcaststore.domain.tiezi;
import cn.itcast.itcaststore.utils.DataSourceUtils;
import cn.itcast.itcaststore.domain.Order;
import cn.itcast.itcaststore.domain.User;
 

/**
 * Servlet implementation class pinglun
 */
public class pinglun extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public pinglun() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String ptitle = request.getParameter("tp");
		
		   String sql = "select pzhe,pcon,pt from pinglun where pt=?";
		   String sqll = "select content from tiezi where title=?";
		   QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource()); 
		   List<String> ls=new ArrayList<>();	
		   List<String> lls=new ArrayList<>();	
			try{
		    
		 	
		   List<Object[]> t=runner.query(sql,new ArrayListHandler(),ptitle);
		 
		    for(Object[] o:t)
					  ls.add(o[0].toString()+"--:"+o[1].toString());
		    
		    
		    List<Object[]> tc=runner.query(sqll,new ArrayListHandler(),ptitle);
		    for(Object[] oo:tc)
				  lls.add(oo[0].toString());	 
			 
			 
		 	// request.setAttribute("tl",ls);
		 //	request.getRequestDispatcher(request.getContextPath()+"/nimingindex.jsp").forward(request, response);
			}
			catch(Exception e){
				 
			} 
			request.setAttribute("pc",ls);
			request.setAttribute("tt",ptitle);
			request.setAttribute("tc",lls);
			 
			request.getRequestDispatcher("/pinglun.jsp").forward(request, response);
	}
 

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
