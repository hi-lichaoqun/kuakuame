package cn.itcast.itcaststore.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;

import cn.itcast.itcaststore.utils.DataSourceUtils;

/**
 * Servlet implementation class regist
 */
public class regist extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public regist() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("usertname");
		String p = request.getParameter("userp");
		//response.getWriter().append(username+p);
		String sql = "insert into user(username,userp) values(?,?)";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		try{
		int row = runner.update(sql, username,p);
		if(row>0){
			 response.getWriter().append("success");
		 }
		}catch(Exception e){
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
