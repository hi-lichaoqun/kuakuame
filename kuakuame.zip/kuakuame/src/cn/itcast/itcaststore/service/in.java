package cn.itcast.itcaststore.service;

import java.io.IOException;
import java.util.*;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.*;

import cn.itcast.itcaststore.domain.Order;
import cn.itcast.itcaststore.utils.DataSourceUtils;
/**
 * Servlet implementation class in
 */
public class in extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public in() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		    String sql = "select title from tiezi";
			QueryRunner runner = new QueryRunner(); 
			List<String> ls=new ArrayList<>();	
				try{
			List<Object[]> l=new ArrayList<>();
			 	l=null;
			 l=runner.query(DataSourceUtils.getConnection(),sql,new ArrayListHandler());
			 
			 int lg=l.size();
			 
			 for(int i=lg-2;i>2;i--){
	 
					 Object[] o=l.get(i);
				 
						  ls.add(o[0].toString());
						  
					 
				 }
				 
			 	// request.setAttribute("tl",ls);
			 //	request.getRequestDispatcher(request.getContextPath()+"/nimingindex.jsp").forward(request, response);
				}
				catch(Exception e){
					 
				} 
				request.setAttribute("tl",ls);
				request.getRequestDispatcher("/nimingindex.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
