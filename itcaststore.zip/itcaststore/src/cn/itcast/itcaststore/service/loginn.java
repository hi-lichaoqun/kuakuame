package cn.itcast.itcaststore.service;

import java.io.IOException;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.Session;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.ArrayListHandler;

import cn.itcast.itcaststore.utils.DataSourceUtils;

/**
 * Servlet implementation class loginn
 */
public class loginn extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginn() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String u = request.getParameter("username");
		String p = request.getParameter("userp");

		String sqll = "select username from user where username=? and userp=?";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		 
		try {

			List<Object[]> t = runner.query(sqll, new ArrayListHandler(), u, p);

			if (t.size() > 0) {
				 
				request.setAttribute("username", u);

				request.getRequestDispatcher("/index.jsp").forward(request, response);

		 }else  {
			 request.setAttribute("usererrorinfo", "用户不存在");
			 request.getRequestDispatcher("/login.jsp").forward(request, response);}
		}catch(Exception e){
			
			 response.getWriter().append("fail");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
