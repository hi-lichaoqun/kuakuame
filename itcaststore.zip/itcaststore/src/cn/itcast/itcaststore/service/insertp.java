package cn.itcast.itcaststore.service;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;

import cn.itcast.itcaststore.utils.DataSourceUtils;

/**
 * Servlet implementation class insertp
 */
public class insertp extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public insertp() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		String u = request.getParameter("pusername");
		u = request.getParameter("u");
		String p = request.getParameter("pcontent");
		String tt = request.getParameter("title");
		Date d = new Date();

		SimpleDateFormat simple = new SimpleDateFormat("YYYY/MM/dd HH:mm:ss");
		// response.getWriter().append("您的评论内容为："+p);
		String sql = "insert into pinglun(pzhe,pcon,pt) values(?,?,?)";
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		try {
			request.setAttribute("tl", tt);
			request.setAttribute("u", u);
			int row = runner.update(sql, u, p + "	" + simple.format(d), tt);
			if (row > 0) {
				// request.setAttribute("tl",tt);
				request.getRequestDispatcher("/NewFile.jsp").forward(request, response);
			}
		} catch (Exception e) {

		}
		// request.getRequestDispatcher("/f.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
