package cn.itcast.itcaststore.domain;

public class tiezi {
	private String pzhe;
	public String getPzhe() {
		return pzhe;
	}
	public void setPzhe(String pzhe) {
		this.pzhe = pzhe;
	}
	public String getPcon() {
		return pcon;
	}
	public void setPcon(String pcon) {
		this.pcon = pcon;
	}
	public String getPt() {
		return pt;
	}
	public void setPt(String pt) {
		this.pt = pt;
	}
	private String pcon;
	private String pt;

}
